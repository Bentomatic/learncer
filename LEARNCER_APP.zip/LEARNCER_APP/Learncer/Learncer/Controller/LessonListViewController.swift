//
//  LessonListViewController.swift
//  Learncer
//
//  Created by Ben Minikwu on 4/21/21.
//

import UIKit

class LessonListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet weak var lessonsTableList: UITableView!
    
    let mathlessons = ["Number & Numeration", "Algebra", "Geometry", "Trigonometry", "Calculus", "Statistics"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lessonsTableList.delegate = self
        lessonsTableList.dataSource = self
        
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mathlessons.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let lessonTopicCell = tableView.dequeueReusableCell(withIdentifier: "lessonTopicCell", for: indexPath)
        lessonTopicCell.textLabel?.text = mathlessons[indexPath.row]
        return lessonTopicCell
        
    }


        // Do any additional setup after loading the view.

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
