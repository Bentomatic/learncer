//
//  HomeViewController.swift
//  Learncer
//
//  Created by Ben Minikwu on 4/11/21.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    @IBOutlet weak var courseCollectionView: UICollectionView!
    
    let titles = ["English", "Literature", "Math", "Physics", "Chemistry", "Biology"]
    
    let courseImages: [UIImage] = [
        
    UIImage(named: "english")!,
    UIImage(named: "literature")!,
    UIImage(named: "math")!,
    UIImage(named: "physics")!,
    UIImage(named: "chemistry")!,
    UIImage(named: "biology")!
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        courseCollectionView.dataSource = self
        courseCollectionView.delegate = self
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return titles.count
    }
    
    
    func collectionView(_ courseCollectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let coursecell = courseCollectionView.dequeueReusableCell(withReuseIdentifier: "CourseCell", for: indexPath) as! CourseCollectionViewCell
        
        coursecell.courseTitleLabel.text = titles[indexPath.item]
        coursecell.courseImageView.image = courseImages[indexPath.item]
        coursecell.layer.borderColor = UIColor.lightGray.cgColor
        coursecell.layer.borderWidth = 0.5
        coursecell.layer.cornerRadius = 10
        return coursecell
    }
    

    func collectionView(_ courseCollectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let coursecell = courseCollectionView.cellForItem(at: indexPath)
        coursecell?.layer.borderColor = UIColor.gray.cgColor
        coursecell?.layer.borderWidth = 2
    }
    
    
    func collectionView(_ courseCollectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        let coursecell = courseCollectionView.cellForItem(at: indexPath)
        coursecell?.layer.borderColor = UIColor.lightGray.cgColor
        coursecell?.layer.borderWidth = 0.5
    }
    
}
