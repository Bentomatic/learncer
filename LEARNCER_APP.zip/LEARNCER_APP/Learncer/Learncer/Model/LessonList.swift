//
//  LessonList.swift
//  Learncer
//
//  Created by Ben Minikwu on 4/21/21.
//

import Foundation

struct LessonsList {
    var mathlessons = ["Number & Numeration", "Algebra", "Geometry", "Trigonometry", "Calculus", "Statistics"]

}
