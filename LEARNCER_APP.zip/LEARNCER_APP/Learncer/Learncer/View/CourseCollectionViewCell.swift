//
//  CourseCollectionViewCell.swift
//  Learncer
//
//  Created by Ben Minikwu on 4/11/21.
//

import UIKit

class CourseCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var courseImageView: UIImageView!

    @IBOutlet weak var courseTitleLabel: UILabel!
    
    @IBOutlet weak var courseProgressView: UIProgressView!
    


}
